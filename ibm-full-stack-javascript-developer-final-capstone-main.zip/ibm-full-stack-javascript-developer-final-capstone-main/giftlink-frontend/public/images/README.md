# All the images without watermark to be used for this project
